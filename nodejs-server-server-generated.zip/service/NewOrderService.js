'use strict';


/**
 * Creates a new customer order in our app.
 * Adds a new order element to the orders.json file.
 *
 * body Order A new order object (optional)
 * no response value expected for this operation
 **/
exports.new_order = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

