'use strict';


/**
 * Gets the order data.
 * Retrieve the order information from the orders.json file.
 *
 * no response value expected for this operation
 **/
exports.get_orders = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

