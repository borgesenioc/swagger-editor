'use strict';


/**
 * Deletes an order from our app.
 * Deletes an order with a matching id from the orders.json file.
 *
 * id String The id of the order.
 * no response value expected for this operation
 **/
exports.delete_id = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

