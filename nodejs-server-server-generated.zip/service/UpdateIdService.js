'use strict';


/**
 * Updates the state of an order in our app.
 * Update the state of an order with a matching id in the orders.json.
 *
 * id String The id of the order.
 * no response value expected for this operation
 **/
exports.update_id = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

